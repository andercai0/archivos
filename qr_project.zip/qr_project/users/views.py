from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from .forms import CustomUserCreationForm, UserSettingsForm, PasswordChangeFormExtended, AttendanceFilterForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import update_session_auth_hash
from .models import CustomUser, Attendance
from .utils import generate_qr_code
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.core.mail import EmailMessage
from datetime import datetime, timedelta
from django.contrib import messages
from django.utils import timezone
from django.conf import settings
import logging
import smtplib

# Configura el logger
logger = logging.getLogger(__name__)

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, '¡Registro exitoso! Ahora puedes iniciar sesión.')
            return redirect('users:login')
    else:
        form = CustomUserCreationForm()

    return render(request, 'users/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                user.ensure_qr_code()
                return redirect('users:home')
            else:
                messages.error(request, 'Nombre de usuario o contraseña incorrectos.')
    else:
        form = AuthenticationForm()

    return render(request, 'users/login.html', {'form': form})

@login_required
def home(request):
    return render(request, 'users/home.html')

@login_required
def scan_qr(request):
    students = CustomUser.objects.filter(user_type='student')
    today = timezone.now().date()  # Obtener la fecha actual
    attendance_dict = {}  # Inicialmente vacío

    return render(request, 'users/scan_qr.html', {
        'students': students,
        'today': today,
        'attendance_dict': attendance_dict,
    })

@login_required
@require_POST
def save_attendance(request):
    if request.method == "POST":
        date = timezone.now().date()
        students = CustomUser.objects.filter(user_type='student')

        for student in students:
            present = request.POST.get(f'attendance-{student.id_number}') == 'on'
            # Crear una nueva instancia de Attendance para cada estudiante
            Attendance.objects.create(
                student=student,
                date=date,
                present=present
            )

        return JsonResponse({"success": True})

    return JsonResponse({"success": False, "error": "Invalid request"})

def attendance_success(request):
    return render(request, 'users/attendance_success.html')

@login_required
def perfil(request):
    user = request.user
    qr_code_url = user.qr_code.url if user.qr_code else None

    context = {
        'qr_code_url': qr_code_url,
    }
    return render(request, 'users/perfil.html', context)

@login_required
def settings_view(request):
    user = request.user
    
    if request.method == 'POST':
        settings_form = UserSettingsForm(request.POST, instance=user)
        password_form = PasswordChangeFormExtended(user, request.POST)
        
        if settings_form.is_valid():
            settings_form.save()
            
        if password_form.is_valid():
            password_form.save()
            update_session_auth_hash(request, password_form.user)  # Important for keeping the user logged in
            return redirect('users:settings')  # Redirect to the same page or success page

    else:
        settings_form = UserSettingsForm(instance=user)
        password_form = PasswordChangeFormExtended(user)
    
    return render(request, 'users/settings.html', {
        'settings_form': settings_form,
        'password_form': password_form
    })

@csrf_exempt
def generate_qr(request):
    if request.method == 'POST':
        user = request.user
        if user.qr_code:
            qr_code_url = user.qr_code.url
        else:
            user_type_label = dict(CustomUser.USER_TYPE_CHOICES).get(user.user_type, user.user_type)
            qr_data = (
                f'{user.id_number}\n'
                f'{user.first_name} {user.last_name}\n'
                f'{user_type_label}'
            )
            qr_code = generate_qr_code(qr_data)
            if qr_code:
                user.qr_code.save(f'{user.username}_qr.png', qr_code, save=True)
                qr_code_url = user.qr_code.url
            else:
                qr_code_url = None
        
        return JsonResponse({'qr_code_url': qr_code_url})
    else:
        return JsonResponse({'error': 'Invalid request method'}, status=400)

@login_required
@require_POST
def send_qr(request):
    user = request.user

    if not user.qr_code or not user.qr_code.path:
        user.ensure_qr_code()

    try:
        email = EmailMessage(
            'Tu código QR de EDUCODE ISTT',
            'Adjunto encontrarás tu código QR.',
            settings.DEFAULT_FROM_EMAIL,
            [user.email],
        )
        with user.qr_code.open('rb') as qr_code_file:
            email.attach(user.qr_code.name, qr_code_file.read(), 'image/png')

        email.send()
        return JsonResponse({'message': 'Código QR enviado a tu correo.'})

    except smtplib.SMTPException as smtp_error:
        logger.error(f'Error SMTP: {str(smtp_error)}')
        return JsonResponse({'error': 'Error al enviar el correo.'}, status=500)

    except Exception as e:
        logger.error(f'Error al enviar el correo: {str(e)}')
        return JsonResponse({'error': 'Error al enviar el código QR'}, status=500)

@login_required
@require_POST
def download_qr(request):
    user = request.user
    if not user.qr_code or not user.qr_code.path:
        user.ensure_qr_code()

    with user.qr_code.open('rb') as qr_code_file:
        response = HttpResponse(qr_code_file.read(), content_type='image/png')
        response['Content-Disposition'] = f'attachment; filename="{user.qr_code.name}"'
        return response
    

def report(request):
    form = AttendanceFilterForm(request.GET or None)
    attendance_data = []
    
    if form.is_valid():
        start_hour_str = form.cleaned_data['start_hour']
        end_hour_str = form.cleaned_data['end_hour']

        try:
            # Convert the strings to datetime.time objects
            start_hour = datetime.strptime(start_hour_str, '%H:%M').time()
            end_hour = datetime.strptime(end_hour_str, '%H:%M').time()

            # Calculate the start and end of the day with the given hours
            now = timezone.now()
            start_datetime = datetime.combine(now.date(), start_hour)
            end_datetime = datetime.combine(now.date(), end_hour)

            if end_datetime <= start_datetime:
                end_datetime += timedelta(days=1)

            # Filter attendance records
            attendance_data = Attendance.objects.filter(
                timestamp__time__range=(start_hour, end_hour)
            ).select_related('student')
        except ValueError:
            # Handle the case where the conversion fails
            form.add_error(None, 'Formato de hora inválido.')
    
    return render(request, 'users/report.html', {
        'form': form,
        'attendance_data': attendance_data
    })

def logout_view(request):
    logout(request)
    return redirect('/')
