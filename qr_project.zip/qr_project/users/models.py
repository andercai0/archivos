from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone
from .utils import generate_qr_code

class CustomUser(AbstractUser):
    USER_TYPE_CHOICES = (
        ('student', 'Estudiante'),
        ('teacher', 'Profesor'),
    )
    email = models.EmailField(unique=True)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    id_number = models.CharField(max_length=20, unique=True)
    date_of_birth = models.DateField(null=True, blank=True)
    user_type = models.CharField(max_length=7, choices=USER_TYPE_CHOICES, default='student')
    qr_code = models.ImageField(upload_to='qr_codes/', blank=True, null=True)

    def save(self, *args, **kwargs):
        # Save the user first to ensure we have a primary key
        super().save(*args, **kwargs)
        # Ensure the QR code is generated if it doesn't exist
        self.ensure_qr_code()

    def ensure_qr_code(self):
        if not self.qr_code:
            user_type_label = dict(self.USER_TYPE_CHOICES).get(self.user_type, self.user_type)
            qr_data = (
                f'{self.id_number}\n'
                f'{self.first_name} {self.last_name}\n'
                f'{user_type_label}'
            )
            qr_code = generate_qr_code(qr_data)
            if qr_code:
                self.qr_code.save(f'{self.username}_qr.png', qr_code, save=True)

    def __str__(self):
        return self.email

class Attendance(models.Model):
    student = models.ForeignKey(CustomUser, on_delete=models.CASCADE, limit_choices_to={'user_type': 'student'})
    date = models.DateField(default=timezone.now)
    present = models.BooleanField(default=False)
    timestamp = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.student.first_name} {self.student.last_name} - {self.date} - {'Present' if self.present else 'Absent'}"

