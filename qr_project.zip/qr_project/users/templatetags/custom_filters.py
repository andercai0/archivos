from django import template

register = template.Library()

@register.filter(name='translate_user_type')
def translate_user_type(user_type):
    translations = {
        'student': 'Estudiante',
        'teacher': 'Profesor'
    }
    return translations.get(user_type, user_type)
